from django.contrib import admin
from .models import Tipocli , Cliente, Tipomascota, Mascotas

# Register your models here.
admin.site.register(Tipocli)
admin.site.register(Cliente)
admin.site.register(Tipomascota)
admin.site.register(Mascotas)
